package com.cg.ebc.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumers;
import com.cg.ebc.dao.*;

public class EBillServiceImpl implements IEBillService{

	IEBillDao billDao;
	public EBillServiceImpl()
	{
		billDao=new EBillDaoImpl();
	}
	@Override
	public boolean isConsumerExists(int consumerNo) {
		
		return billDao.isConsumerExists(consumerNo);
	}

	@Override
	public Consumers getConsumer(int consumerNo) {
		
		return billDao.getConsumer(consumerNo);
	}

	@Override
	public BillDetails addBillDetails(BillDetails billDetails) {
		
		return billDao.addBillDetails(billDetails);
	}
	@Override
	public List<Consumers> getConsumers() {
		// TODO Auto-generated method stub
		return billDao.getConsumers();
	}
	@Override
	public List<BillDetails> getBillDetails(int consumerno) {
		// TODO Auto-generated method stub
		return billDao.getBillDetails(consumerno);
	}


}
