package com.cg.ebc.service;



import java.util.ArrayList;
import java.util.List;

import com.cg.ebc.bean.BillDetails;
import com.cg.ebc.bean.Consumers;


public interface IEBillService {
	public boolean isConsumerExists(int consumerNo);
	public Consumers getConsumer(int consumerNo);
	public BillDetails addBillDetails(BillDetails billDetails);
	public List<Consumers> getConsumers();
	public List<BillDetails> getBillDetails(int consumerno);
}
