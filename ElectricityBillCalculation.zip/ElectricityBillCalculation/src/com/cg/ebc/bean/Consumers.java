package com.cg.ebc.bean;

public class Consumers {
	
	private int consumer_num;
	private String consumer_name;
	private String consumer_addr;
	public int getConsumer_num() {
		return consumer_num;
	}
	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}
	public String getConsumer_name() {
		return consumer_name;
	}
	public void setConsumer_name(String consumer_name) {
		this.consumer_name = consumer_name;
	}
	public String getConsumer_addr() {
		return consumer_addr;
	}
	public void setConsumer_addr(String consumer_addr) {
		this.consumer_addr = consumer_addr;
	}
	public Consumers(int consumer_num, String consumer_name,
			String consumer_addr) {
		super();
		this.consumer_num = consumer_num;
		this.consumer_name = consumer_name;
		this.consumer_addr = consumer_addr;
	}
	public Consumers() {
		super();
	}
	@Override
	public String toString() {
		return "Consumers [consumer_num=" + consumer_num + ", consumer_name="
				+ consumer_name + ", consumer_addr=" + consumer_addr + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + consumer_num;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Consumers other = (Consumers) obj;
		if (consumer_num != other.consumer_num)
			return false;
		return true;
	}
	
	

}
